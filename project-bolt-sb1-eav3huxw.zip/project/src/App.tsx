import React, { useState, useMemo } from 'react';
import Header from './components/Header';
import SearchBar from './components/SearchBar';
import MonumentCard from './components/MonumentCard';
import MonumentDetail from './components/MonumentDetail';
import FilterSidebar from './components/FilterSidebar';
import { monuments, Monument } from './data/monuments';
import { Search, MapPin, Building, Heart, Sparkles } from 'lucide-react';

function App() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedState, setSelectedState] = useState('');
  const [selectedType, setSelectedType] = useState('');
  const [selectedMonument, setSelectedMonument] = useState<Monument | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const filteredMonuments = useMemo(() => {
    return monuments.filter(monument => {
      const matchesQuery = searchQuery === '' || 
        monument.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        monument.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
        monument.overview.toLowerCase().includes(searchQuery.toLowerCase()) ||
        monument.type.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesState = selectedState === '' || monument.state === selectedState;
      const matchesType = selectedType === '' || monument.type === selectedType;
      
      return matchesQuery && matchesState && matchesType;
    });
  }, [searchQuery, selectedState, selectedType]);

  const handleSearch = (query: string, state: string, type: string) => {
    setSearchQuery(query);
    setSelectedState(state);
    setSelectedType(type);
  };

  const handleMonumentClick = (monument: Monument) => {
    setSelectedMonument(monument);
  };

  const handleBackToSearch = () => {
    setSelectedMonument(null);
  };

  if (selectedMonument) {
    return <MonumentDetail monument={selectedMonument} onBack={handleBackToSearch} />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header onMenuClick={() => setSidebarOpen(true)} />
      
      <div className="flex">
        <FilterSidebar
          isOpen={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
          selectedState={selectedState}
          selectedType={selectedType}
          onStateChange={setSelectedState}
          onTypeChange={setSelectedType}
        />
        
        <main className="flex-1">
          {/* Hero Section */}
          <div className="relative bg-gradient-to-br from-orange-500 via-red-500 to-purple-600 text-white">
            <div className="absolute inset-0 bg-black/20"></div>
            <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
              <div className="text-center mb-12">
                <div className="flex items-center justify-center space-x-3 mb-6">
                  <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
                    <Heart className="w-8 h-8 text-white" />
                  </div>
                  <div>
                    <h1 className="text-4xl md:text-5xl font-bold">Sanskriti Dharohar</h1>
                    <p className="text-xl text-white/90">Discover India's Sacred Heritage</p>
                  </div>
                </div>
                <p className="text-lg text-white/80 max-w-2xl mx-auto mb-8">
                  Explore the rich spiritual heritage of India through temples, mosques, churches, and gurudwaras across various states.
                </p>
                
                {/* Search Bar */}
                <SearchBar onSearch={handleSearch} />
              </div>
              
              {/* Quick Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
                <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
                  <Building className="w-8 h-8 mx-auto mb-2" />
                  <div className="text-2xl font-bold">{monuments.length}+</div>
                  <div className="text-sm text-white/80">Sacred Sites</div>
                </div>
                <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
                  <MapPin className="w-8 h-8 mx-auto mb-2" />
                  <div className="text-2xl font-bold">7</div>
                  <div className="text-sm text-white/80">Indian States</div>
                </div>
                <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
                  <Sparkles className="w-8 h-8 mx-auto mb-2" />
                  <div className="text-2xl font-bold">4</div>
                  <div className="text-sm text-white/80">Religious Types</div>
                </div>
                <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
                  <Heart className="w-8 h-8 mx-auto mb-2" />
                  <div className="text-2xl font-bold">Rich</div>
                  <div className="text-sm text-white/80">Heritage</div>
                </div>
              </div>
            </div>
          </div>

          {/* Results Section */}
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            {/* Results Header */}
            <div className="flex items-center justify-between mb-8">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">
                  {searchQuery || selectedState || selectedType ? 'Search Results' : 'All Monuments'}
                </h2>
                <p className="text-gray-600">
                  {filteredMonuments.length} monument{filteredMonuments.length !== 1 ? 's' : ''} found
                </p>
              </div>
              
              {/* Active Filters */}
              {(selectedState || selectedType) && (
                <div className="flex flex-wrap gap-2">
                  {selectedState && (
                    <span className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-blue-100 text-blue-800">
                      {selectedState}
                      <button
                        onClick={() => setSelectedState('')}
                        className="ml-2 text-blue-600 hover:text-blue-800"
                      >
                        ×
                      </button>
                    </span>
                  )}
                  {selectedType && (
                    <span className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-green-100 text-green-800">
                      {selectedType}
                      <button
                        onClick={() => setSelectedType('')}
                        className="ml-2 text-green-600 hover:text-green-800"
                      >
                        ×
                      </button>
                    </span>
                  )}
                </div>
              )}
            </div>

            {/* No Results */}
            {filteredMonuments.length === 0 && (
              <div className="text-center py-16">
                <Search className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">No monuments found</h3>
                <p className="text-gray-600 mb-6">Try adjusting your search criteria or filters.</p>
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedState('');
                    setSelectedType('');
                  }}
                  className="px-6 py-3 bg-orange-500 text-white rounded-xl font-semibold hover:bg-orange-600 transition-colors"
                >
                  Clear All Filters
                </button>
              </div>
            )}

            {/* Monuments Grid */}
            {filteredMonuments.length > 0 && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {filteredMonuments.map((monument) => (
                  <MonumentCard
                    key={monument.id}
                    monument={monument}
                    onClick={handleMonumentClick}
                  />
                ))}
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}

export default App;