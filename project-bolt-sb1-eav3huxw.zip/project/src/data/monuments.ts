export interface Monument {
  id: string;
  name: string;
  type: 'Temple' | 'Mosque' | 'Church' | 'Gurudwara';
  state: string;
  district: string;
  location: string;
  overview: string;
  image: string;
  timings?: string;
  history: string;
  amenities: string[];
  festivals?: string[];
  offerings?: string[];
  accessibility: string;
  nearbyAttractions: string[];
  nearbyHotels: string[];
  nearbyRestaurants: string[];
  localFood: string[];
  contact?: string;
  website?: string;
  coordinates?: { lat: number; lng: number };
  established?: string;
  architecture?: string;
  significance?: string;
  deities?: string[];
  educationalServices?: string[];
  marriageServices?: boolean;
  daanDakshina?: string[];
  foodForDevotees?: string[];
  videoLinks?: string[];
}

export const monuments: Monument[] = [
  {
    id: 'tarakeswar-temple',
    name: 'Taraknath Temple',
    type: 'Temple',
    state: 'West Bengal',
    district: 'Hooghly',
    location: 'Tarakeswar, Hooghly District',
    overview: 'Renowned pilgrimage site with Taraknath Temple dedicated to Lord Shiva. Known as "Baba Dham," located 58 km from Kolkata and well-connected by transport.',
    image: 'https://images.pexels.com/photos/3112182/pexels-photo-3112182.jpeg',
    timings: 'Daily prayers from early morning to late evening',
    history: 'Built in 1729 AD by Raja Bharamalla Rao, houses a Shayambhu linga and includes the sacred Dudhpukur pond. The annual Shiva Yatra during Shravan month draws over 10 million devotees.',
    established: '1729 AD',
    amenities: ['Sacred Dudhpukur pond', 'Prayer halls', 'Prasad distribution', 'Accommodation facilities', 'Parking'],
    festivals: ['Shiva Yatra (Shravan month)', 'Maha Shivratri', 'Sawan Monday celebrations'],
    offerings: ['Bel leaves', 'Sacred water', 'Flowers', 'Milk offerings'],
    accessibility: '39 km from Baidyabati, well-connected by road and rail',
    nearbyAttractions: ['Dudhpukur pond', 'Local markets', 'Historical sites'],
    nearbyHotels: ['Local guest houses', 'Dharamshala accommodations'],
    nearbyRestaurants: ['Traditional Bengali cuisine', 'Vegetarian restaurants'],
    localFood: ['Bengali sweets', 'Temple prasad', 'Local street food'],
    deities: ['Lord Shiva (Taraknath)', 'Shayambhu linga'],
    educationalServices: ['Tarakeswar Degree College', 'Various high schools', 'Rani Rashmoni Green University (under construction)'],
    daanDakshina: ['Monetary offerings', 'Food donations', 'Service contributions'],
    foodForDevotees: ['Free prasad distribution', 'Community meals during festivals']
  },
  {
    id: 'dakshineswar-kali-temple',
    name: 'Dakshineswar Kali Temple',
    type: 'Temple',
    state: 'West Bengal',
    district: 'Kolkata',
    location: 'Dakshineswar, Kolkata',
    overview: 'Prominent Hindu temple on Hooghly River, dedicated to Bhavatarini (Kali). Built in 1855 by Rani Rashmoni and associated with the mystic Ramakrishna Paramhansa.',
    image: 'https://images.pexels.com/photos/9754071/pexels-photo-9754071.jpeg',
    timings: '7 AM-12 PM & 3:30 PM-9 PM daily',
    history: 'Built in 1855 by Rani Rashmoni, this temple became famous as the spiritual center of 19th-century mystic Ramakrishna Paramhansa, who served as head priest.',
    established: '1855',
    amenities: ['12 Shiva Temples', 'Radha-Krishna Temple', 'Bathing Ghat', 'Ramakrishna\'s preserved room', 'Prayer halls'],
    festivals: ['Kali Puja', 'Durga Puja', 'Diwali celebrations'],
    offerings: ['Red hibiscus flowers', 'Sweets', 'Coconut', 'Red cloth'],
    accessibility: '10-minute walk from Dakshineswar Railway Station',
    nearbyAttractions: ['Ramakrishna\'s room', 'Bathing ghat', 'Hooghly River'],
    nearbyHotels: ['Kolkata city hotels', 'Guest houses'],
    nearbyRestaurants: ['Bengali cuisine restaurants', 'Street food vendors'],
    localFood: ['Bengali fish curry', 'Sweets', 'Prasad'],
    deities: ['Bhavatarini (Kali)', 'Radha-Krishna', '12 Shiva lingams'],
    daanDakshina: ['Temple donations', 'Flower offerings', 'Food contributions'],
    foodForDevotees: ['Prasad distribution', 'Community meals'],
    significance: 'Associated with Ramakrishna Paramhansa and spiritual awakening'
  },
  {
    id: 'kalighat-kali-temple',
    name: 'Kalighat Kali Temple',
    type: 'Temple',
    state: 'West Bengal',
    district: 'Kolkata',
    location: 'Kalighat, South Kolkata',
    overview: 'Renowned Hindu temple and one of 51 Shakti Peethas where Sati\'s body parts fell. Dedicated to Kali and over 200 years old.',
    image: 'https://images.pexels.com/photos/8832878/pexels-photo-8832878.jpeg',
    timings: '5 AM-2 PM & 5 PM-10:30 PM daily',
    history: 'Current structure is over 200 years old. Features a unique Kali idol with three eyes, long tongue, and four hands. One of the most sacred Shakti Peethas.',
    amenities: ['Prayer halls', 'Prasad shops', 'Limited on-site facilities'],
    festivals: ['Kali Puja', 'Durga Puja', 'Poila Boishakh'],
    offerings: ['Red hibiscus', 'Sweets', 'Coconut', 'Animal sacrifice (traditional)'],
    accessibility: 'Walkable from Jatin Das Park metro station, near Kalighat metro',
    nearbyAttractions: ['Kalighat metro station', 'Local markets', 'Nirmal Hriday'],
    nearbyHotels: ['South Kolkata hotels', 'Budget accommodations'],
    nearbyRestaurants: ['Bengali restaurants', 'Street food stalls'],
    localFood: ['Bengali sweets', 'Fish preparations', 'Prasad'],
    deities: ['Kali (unique three-eyed form)'],
    significance: 'One of 51 Shakti Peethas, ancient pilgrimage site'
  },
  {
    id: 'tarapith-temple',
    name: 'Tarapith Temple',
    type: 'Temple',
    state: 'West Bengal',
    district: 'Birbhum',
    location: 'Tarapith, Birbhum District',
    overview: 'Significant Hindu pilgrimage site dedicated to Goddess Tara in Tantric tradition. One of 108 Shakti Peethas where Sati\'s third eye fell.',
    image: 'https://images.pexels.com/photos/12155400/pexels-photo-12155400.jpeg',
    timings: '6 AM-2 PM & 7 PM-11 PM daily',
    history: 'Associated with Tantric saint Bamakhepa whose ashram is nearby. One of the most important Tantric pilgrimage sites in Bengal.',
    amenities: ['Prasad distribution', 'Accommodation', 'Local eateries', 'Ashram facilities'],
    festivals: ['Kali Puja', 'Tara Puja', 'Tantric festivals'],
    offerings: ['Red flowers', 'Sweets', 'Wine (traditional tantric offering)', 'Fish'],
    accessibility: '9 km from Rampurhat Junction railway station (20-30 min by auto/taxi or bus)',
    nearbyAttractions: ['Bamakhepa\'s ashram', 'Tantric sites', 'Rural Bengal landscape'],
    nearbyHotels: ['Local guest houses', 'Pilgrimage accommodations'],
    nearbyRestaurants: ['Bengali cuisine', 'Vegetarian options'],
    localFood: ['Bengali fish curry', 'Sweets', 'Local preparations'],
    deities: ['Goddess Tara (Tantric form)'],
    significance: 'Major Tantric pilgrimage center, Shakti Peetha'
  },
  {
    id: 'belur-math',
    name: 'Belur Math',
    type: 'Temple',
    state: 'West Bengal',
    district: 'Howrah',
    location: 'Belur, Howrah',
    overview: 'Headquarters of Ramakrishna Math and Mission, founded by Swami Vivekananda. Symbolizes unity of religions with its unique architecture.',
    image: 'https://images.pexels.com/photos/14676995/pexels-photo-14676995.jpeg',
    timings: '6 AM-11:30 AM & 4 PM-7 PM daily',
    history: 'Established in 1897 by Swami Vivekananda. The architecture uniquely fuses Hindu, Christian, and Islamic motifs representing universal spirituality.',
    established: '1897',
    amenities: ['Ramakrishna Museum', 'Bookstore', 'Limited accommodation', 'Canteen', 'Prayer halls'],
    festivals: ['Ramakrishna Jayanti', 'Vivekananda Jayanti', 'Kalpataru Day'],
    offerings: ['Flowers', 'Books', 'Educational materials'],
    accessibility: '6 km from Howrah Junction (20 min by taxi/auto), Belur Math railway station nearby',
    nearbyAttractions: ['Hooghly River', 'Museum', 'Meditation halls'],
    nearbyHotels: ['Howrah hotels', 'Math guest house'],
    nearbyRestaurants: ['Vegetarian restaurants', 'Math canteen'],
    localFood: ['Simple vegetarian meals', 'Bengali sweets'],
    significance: 'Universal spiritual center, promotes religious harmony',
    educationalServices: ['Spiritual education', 'Cultural programs', 'Library services']
  },
  {
    id: 'mayapur-iskcon-temple',
    name: 'Mayapur ISKCON Temple',
    type: 'Temple',
    state: 'West Bengal',
    district: 'Nadia',
    location: 'Mayapur, Nadia District',
    overview: 'ISKCON world headquarters and significant pilgrimage site for Lord Krishna devotees. Features the upcoming "Temple of the Vedic Planetarium."',
    image: 'https://images.pexels.com/photos/10574970/pexels-photo-10574970.jpeg',
    timings: '4:30 AM-1 PM & 4 PM-8:30 PM daily',
    history: 'Birthplace of Sri Chaitanya Mahaprabhu, the 15th-century saint and founder of Gaudiya Vaishnavism. The Temple of Vedic Planetarium under construction aims to be a global monument.',
    amenities: ['Guesthouses', 'Free prasadam', 'Restaurants', 'Educational tours', 'Cultural programs'],
    festivals: ['Janmashtami', 'Gaura Purnima', 'Ratha Yatra'],
    offerings: ['Tulsi leaves', 'Flowers', 'Sweets', 'Devotional items'],
    accessibility: '18 km from Krishnanagar City Junction (30-40 min by taxi/auto or bus)',
    nearbyAttractions: ['Ganges-Jalangi confluence', 'Chaitanya\'s birthplace', 'Vedic Planetarium'],
    nearbyHotels: ['ISKCON guesthouses', 'Local accommodations'],
    nearbyRestaurants: ['Vegetarian restaurants', 'Prasadam halls'],
    localFood: ['Krishna prasadam', 'Vegetarian Bengali cuisine'],
    deities: ['Sri Sri Radha Madhava', 'Sri Chaitanya Mahaprabhu'],
    educationalServices: ['Vedic education', 'Cultural programs', 'Spiritual courses'],
    foodForDevotees: ['Free prasadam', 'Community meals', 'Festival feasts']
  },
  {
    id: 'basilica-holy-rosary',
    name: 'Basilica of the Holy Rosary (Bandel Church)',
    type: 'Church',
    state: 'West Bengal',
    district: 'Hooghly',
    location: 'Bandel, Hooghly District',
    overview: 'One of West Bengal\'s oldest Christian churches, built in 1599 by Portuguese. Dedicated to Our Lady of the Rosary and designated as a minor basilica since 1988.',
    image: 'https://images.pexels.com/photos/161159/church-our-lady-of-lourdes-grotto-catholic-161159.jpeg',
    timings: 'Daily services (check official sources for exact timings)',
    history: 'Built in 1599 by Portuguese settlers, burnt in 1632 by Mughals, and rebuilt in 1660. Became a minor basilica in 1988 by Pope John Paul II.',
    established: '1599',
    amenities: ['Chapel', 'Prayer halls', 'Historical artifacts'],
    festivals: ['Christmas', 'Easter', 'Feast of Our Lady of the Rosary'],
    accessibility: '2 km from Bandel Junction (10-15 min by rickshaw/auto, 20-25 min walk)',
    nearbyAttractions: ['Hooghly River', 'Historical Portuguese sites'],
    nearbyHotels: ['Hooghly district accommodations'],
    nearbyRestaurants: ['Local Bengali cuisine', 'Christian community eateries'],
    localFood: ['Bengali-Portuguese fusion', 'Traditional Bengali food'],
    significance: 'Historic Portuguese Catholic heritage site'
  },
  {
    id: 'st-pauls-cathedral',
    name: 'St. Paul\'s Cathedral',
    type: 'Church',
    state: 'West Bengal',
    district: 'Kolkata',
    location: 'Cathedral Road, Kolkata',
    overview: 'Largest church in Kolkata and first Anglican cathedral in Asia. Features magnificent Indo-Gothic architecture.',
    image: 'https://images.pexels.com/photos/208301/pexels-photo-208301.jpeg',
    timings: '9 AM-12 PM & 3 PM-6 PM daily',
    history: 'Completed in 1847, reconstructed after earthquakes in 1897 and 1934. Features beautiful stained-glass windows and frescoes.',
    established: '1847',
    amenities: ['Library', 'Prayer halls', 'Historical displays'],
    festivals: ['Christmas', 'Easter', 'Anglican celebrations'],
    accessibility: '5 km from Sealdah Railway Station, near Maidan Metro Station',
    nearbyAttractions: ['Victoria Memorial', 'Nandan', 'Birla Planetarium'],
    nearbyHotels: ['Central Kolkata hotels'],
    nearbyRestaurants: ['Park Street restaurants', 'Fine dining'],
    localFood: ['Continental cuisine', 'Bengali specialties'],
    architecture: 'Indo-Gothic style with magnificent spire',
    significance: 'First Anglican cathedral in Asia'
  },
  {
    id: 'nakhoda-mosque',
    name: 'Nakhoda Mosque',
    type: 'Mosque',
    state: 'West Bengal',
    district: 'Kolkata',
    location: 'Chitpur, Burrabazar, Kolkata',
    overview: 'Largest and most significant mosque in West Bengal. Completed in 1926, serving as the principal mosque of Kolkata following Hanafi school of Sunni Islam.',
    image: 'https://images.pexels.com/photos/15389064/pexels-photo-15389064.jpeg',
    timings: 'Daily prayers five times, Friday congregational prayers',
    history: 'Originally two smaller mosques pre-1854. Commissioned by Haji Zakariah and rebuilt in 1926 by Kutchi Memon Jamat at a cost of ₹1.5 million.',
    established: '1926',
    amenities: ['Prayer hall (capacity 10,000)', 'Ablution facilities', 'Islamic library'],
    festivals: ['Eid ul-Fitr', 'Eid ul-Adha', 'Milad un-Nabi'],
    accessibility: 'Located in Burrabazar area, well-connected by public transport',
    nearbyAttractions: ['Burrabazar market', 'Chitpur area'],
    nearbyHotels: ['Central Kolkata accommodations'],
    nearbyRestaurants: ['Mughlai cuisine', 'Halal restaurants'],
    localFood: ['Biryani', 'Kebabs', 'Mughlai dishes'],
    architecture: 'Mughal and Indo-Islamic style inspired by Akbar\'s Mausoleum',
    significance: 'Largest mosque in Eastern India, major Islamic center'
  },
  {
    id: 'adina-mosque',
    name: 'Adina Mosque',
    type: 'Mosque',
    state: 'West Bengal',
    district: 'Malda',
    location: 'Pandua, Malda',
    overview: 'Historic royal mosque, once the largest in the Indian subcontinent. Built 1373–1375 by Sikandar Shah of Bengal Sultanate, who is buried here.',
    image: 'https://images.pexels.com/photos/17834411/pexels-photo-17834411.jpeg',
    timings: 'Historical site, visit during daylight hours',
    history: 'Built to symbolize Bengal\'s independence from Delhi Sultanate. Located in the royal capital Pandua, it reflects the Bengal Sultanate\'s architectural ambition.',
    established: '1373-1375',
    amenities: ['Historical ruins', 'Archaeological site', 'Guided tours'],
    accessibility: '12 km south of Malda town',
    nearbyAttractions: ['Gour archaeological sites', 'Other historical monuments'],
    nearbyHotels: ['Malda accommodations'],
    nearbyRestaurants: ['Local Bengali cuisine'],
    localFood: ['Malda mangoes', 'Bengali fish preparations'],
    architecture: 'Indo-Islamic style integrating Bengali, Arab, Persian, and Byzantine elements',
    significance: 'Major historical and architectural landmark of Bengal Sultanate'
  },
  {
    id: 'gurudwara-badi-sangat',
    name: 'Gurdwara Sri Badi Sangat Sahib',
    type: 'Gurudwara',
    state: 'West Bengal',
    district: 'Kolkata',
    location: 'Barabazar Market, Kolkata',
    overview: 'Historic Sikh Gurdwara visited by Guru Nanak Sahib Ji in 1510 and Guru Tegh Bahadur Sahib Ji in 1668. Located in the bustling Barabazar Market.',
    image: 'https://images.pexels.com/photos/12481298/pexels-photo-12481298.jpeg',
    timings: 'Daily prayers and continuous Langar service',
    history: 'Guru Nanak healed an epidemic here and established Guru Ki Sangat, staying for 12 days. Guru Tegh Bahadur instructed continuous religious programs and 24-hour Langar service.',
    amenities: ['Main prayer hall', 'Langar Hall', 'Diwan Hall', 'Library', 'Limited accommodation', 'Charitable services'],
    festivals: ['Guru Nanak Jayanti', 'Baisakhi', 'Guru Tegh Bahadur Martyrdom Day'],
    accessibility: 'Howrah Junction (4 km), Mahakaran Metro (1.5 km), MG Road Metro (2 km)',
    nearbyAttractions: ['Barabazar Market', 'Howrah Bridge', 'Historical sites'],
    nearbyHotels: ['Central Kolkata hotels'],
    nearbyRestaurants: ['Punjabi cuisine', 'Langar (free meals)'],
    localFood: ['Langar meals', 'Punjabi dishes', 'Bengali cuisine'],
    practices: ['Daily prayers', 'Kirtan', 'Langar', 'Gurpurabs', 'Akhand Path', 'Seva'],
    foodForDevotees: ['24-hour Langar service', 'Free community meals'],
    significance: 'Historic connection to two Sikh Gurus, continuous service tradition'
  },
  {
    id: 'gurudwara-chhota-sangat',
    name: 'Gurdwara Chhota Sikh Sangat',
    type: 'Gurudwara',
    state: 'West Bengal',
    district: 'Kolkata',
    location: '112 Cotton Street, Raja Katra, Bara Bazar, Jorasanko, Kolkata',
    overview: 'Historic Sikh temple visited by Guru Tegh Bahadur and Guru Gobind Singh. Located adjacent to Gurudwara Bara Sikh Sangat in the bustling Bara Bazar area.',
    image: 'https://images.pexels.com/photos/13830482/pexels-photo-13830482.jpeg',
    timings: 'Daily prayers and regular services',
    history: 'Holds profound religious and historical importance due to visits by multiple Sikh Gurus, making it a significant pilgrimage site.',
    amenities: ['Traditional prayer hall', 'Community services', 'Religious programs'],
    festivals: ['Guru Gobind Singh Jayanti', 'Guru Tegh Bahadur Martyrdom Day', 'Baisakhi'],
    accessibility: 'Located in bustling Bara Bazar area with excellent local transport connectivity',
    nearbyAttractions: ['Gurudwara Bara Sikh Sangat', 'Bara Bazar Market', 'Jorasanko area'],
    nearbyHotels: ['North Kolkata accommodations'],
    nearbyRestaurants: ['Punjabi cuisine', 'Bengali eateries'],
    localFood: ['Gurdwara langar', 'Local Bengali food'],
    architecture: 'Traditional Sikh design with square hall, green royal pillars, and wooden beams',
    significance: 'Multiple Guru visits, adjacent to major Gurdwara'
  }
];

export const states = ['West Bengal', 'Karnataka', 'Tamil Nadu', 'Telangana', 'Kerala', 'Andaman and Nicobar Islands', 'Puducherry'];
export const types = ['Temple', 'Mosque', 'Church', 'Gurudwara'];