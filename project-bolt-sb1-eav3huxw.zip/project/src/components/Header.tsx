import React from 'react';
import { Search, Menu, Heart } from 'lucide-react';

interface HeaderProps {
  onMenuClick: () => void;
}

const Header: React.FC<HeaderProps> = ({ onMenuClick }) => {
  return (
    <header className="bg-white shadow-md border-b-2 border-orange-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-3">
            <button
              onClick={onMenuClick}
              className="md:hidden p-2 rounded-md text-gray-600 hover:text-orange-600 hover:bg-orange-50 transition-colors"
            >
              <Menu className="h-6 w-6" />
            </button>
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-orange-500 to-red-600 rounded-full flex items-center justify-center">
                <Heart className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Sanskriti Dharohar</h1>
                <p className="text-xs text-gray-600 hidden sm:block">Discover India's Sacred Heritage</p>
              </div>
            </div>
          </div>
          
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#" className="text-gray-600 hover:text-orange-600 font-medium transition-colors">Home</a>
            <a href="#" className="text-gray-600 hover:text-orange-600 font-medium transition-colors">Monuments</a>
            <a href="#" className="text-gray-600 hover:text-orange-600 font-medium transition-colors">States</a>
            <a href="#" className="text-gray-600 hover:text-orange-600 font-medium transition-colors">About</a>
            <a href="#" className="text-gray-600 hover:text-orange-600 font-medium transition-colors">Contact</a>
          </nav>
          
          <div className="flex items-center space-x-4">
            <button className="p-2 rounded-full bg-orange-100 text-orange-600 hover:bg-orange-200 transition-colors">
              <Search className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;