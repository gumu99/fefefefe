import React from 'react';
import { X, MapPin, Building, Calendar, Star } from 'lucide-react';
import { states, types } from '../data/monuments';

interface FilterSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  selectedState: string;
  selectedType: string;
  onStateChange: (state: string) => void;
  onTypeChange: (type: string) => void;
}

const FilterSidebar: React.FC<FilterSidebarProps> = ({
  isOpen,
  onClose,
  selectedState,
  selectedType,
  onStateChange,
  onTypeChange
}) => {
  if (!isOpen) return null;

  return (
    <>
      {/* Overlay */}
      <div 
        className="fixed inset-0 bg-black bg-opacity-50 z-40 md:hidden"
        onClick={onClose}
      />
      
      {/* Sidebar */}
      <div className={`
        fixed top-0 left-0 h-full w-80 bg-white shadow-xl transform transition-transform duration-300 ease-in-out z-50
        ${isOpen ? 'translate-x-0' : '-translate-x-full'}
        md:relative md:translate-x-0 md:shadow-none md:border-r md:border-gray-200
      `}>
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-gray-900">Filters</h2>
            <button
              onClick={onClose}
              className="p-2 rounded-lg text-gray-400 hover:text-gray-600 hover:bg-gray-100 md:hidden"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="space-y-6">
            {/* State Filter */}
            <div>
              <label className="flex items-center space-x-2 text-sm font-medium text-gray-700 mb-3">
                <MapPin className="w-4 h-4" />
                <span>State</span>
              </label>
              <div className="space-y-2">
                <button
                  onClick={() => onStateChange('')}
                  className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors ${
                    selectedState === '' 
                      ? 'bg-orange-100 text-orange-800 border border-orange-200' 
                      : 'text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  All States
                </button>
                {states.map((state) => (
                  <button
                    key={state}
                    onClick={() => onStateChange(state)}
                    className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors ${
                      selectedState === state 
                        ? 'bg-orange-100 text-orange-800 border border-orange-200' 
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    {state}
                  </button>
                ))}
              </div>
            </div>

            {/* Type Filter */}
            <div>
              <label className="flex items-center space-x-2 text-sm font-medium text-gray-700 mb-3">
                <Building className="w-4 h-4" />
                <span>Religious Type</span>
              </label>
              <div className="space-y-2">
                <button
                  onClick={() => onTypeChange('')}
                  className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors ${
                    selectedType === '' 
                      ? 'bg-orange-100 text-orange-800 border border-orange-200' 
                      : 'text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  All Types
                </button>
                {types.map((type) => (
                  <button
                    key={type}
                    onClick={() => onTypeChange(type)}
                    className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors ${
                      selectedType === type 
                        ? 'bg-orange-100 text-orange-800 border border-orange-200' 
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    {type}
                  </button>
                ))}
              </div>
            </div>

            {/* Quick Stats */}
            <div className="border-t border-gray-200 pt-6">
              <h3 className="text-sm font-medium text-gray-700 mb-3">Quick Stats</h3>
              <div className="space-y-2 text-sm text-gray-600">
                <div className="flex items-center space-x-2">
                  <Building className="w-4 h-4" />
                  <span>15+ Sacred Monuments</span>
                </div>
                <div className="flex items-center space-x-2">
                  <MapPin className="w-4 h-4" />
                  <span>7 Indian States</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Star className="w-4 h-4" />
                  <span>Rich Cultural Heritage</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default FilterSidebar;