import React from 'react';
import { MapPin, Clock, Star, ArrowRight } from 'lucide-react';
import { Monument } from '../data/monuments';

interface MonumentCardProps {
  monument: Monument;
  onClick: (monument: Monument) => void;
}

const MonumentCard: React.FC<MonumentCardProps> = ({ monument, onClick }) => {
  const getTypeColor = (type: string) => {
    switch (type) {
      case 'Temple':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'Mosque':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'Church':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Gurudwara':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <div 
      className="bg-white rounded-2xl shadow-lg border border-gray-200 overflow-hidden hover:shadow-xl transition-all duration-300 cursor-pointer group"
      onClick={() => onClick(monument)}
    >
      <div className="relative h-48 overflow-hidden">
        <img
          src={monument.image}
          alt={monument.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute top-4 left-4">
          <span className={`px-3 py-1 rounded-full text-sm font-medium border ${getTypeColor(monument.type)}`}>
            {monument.type}
          </span>
        </div>
        <div className="absolute top-4 right-4">
          <div className="bg-white/90 backdrop-blur-sm rounded-full p-2">
            <Star className="w-4 h-4 text-yellow-500 fill-current" />
          </div>
        </div>
      </div>
      
      <div className="p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-orange-600 transition-colors">
          {monument.name}
        </h3>
        
        <div className="flex items-center space-x-2 text-gray-600 mb-3">
          <MapPin className="w-4 h-4" />
          <span className="text-sm">{monument.location}</span>
        </div>
        
        {monument.timings && (
          <div className="flex items-center space-x-2 text-gray-600 mb-3">
            <Clock className="w-4 h-4" />
            <span className="text-sm">{monument.timings}</span>
          </div>
        )}
        
        <p className="text-gray-700 text-sm leading-relaxed mb-4 line-clamp-3">
          {monument.overview}
        </p>
        
        <div className="flex items-center justify-between">
          <div className="text-sm text-gray-500">
            {monument.district}, {monument.state}
          </div>
          <button className="flex items-center space-x-1 text-orange-600 hover:text-orange-700 font-medium group-hover:translate-x-1 transition-transform">
            <span>Learn More</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default MonumentCard;