import React from 'react';
import { 
  ArrowLeft, 
  MapPin, 
  Clock, 
  Calendar, 
  Heart, 
  Utensils, 
  Hotel, 
  Camera,
  Globe,
  Phone,
  Star,
  Info,
  Users,
  Gift,
  Sparkles,
  GraduationCap,
  Car,
  TreePine
} from 'lucide-react';
import { Monument } from '../data/monuments';

interface MonumentDetailProps {
  monument: Monument;
  onBack: () => void;
}

const MonumentDetail: React.FC<MonumentDetailProps> = ({ monument, onBack }) => {
  const getTypeColor = (type: string) => {
    switch (type) {
      case 'Temple':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'Mosque':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'Church':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Gurudwara':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const InfoCard: React.FC<{ title: string; items: string[]; icon: React.ReactNode }> = ({ title, items, icon }) => (
    <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6">
      <div className="flex items-center space-x-2 mb-4">
        {icon}
        <h3 className="text-lg font-semibold text-gray-900">{title}</h3>
      </div>
      <ul className="space-y-2">
        {items.map((item, index) => (
          <li key={index} className="text-gray-700 text-sm flex items-start space-x-2">
            <span className="w-1.5 h-1.5 bg-orange-500 rounded-full mt-2 flex-shrink-0"></span>
            <span>{item}</span>
          </li>
        ))}
      </ul>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <button
            onClick={onBack}
            className="flex items-center space-x-2 text-gray-600 hover:text-orange-600 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span className="font-medium">Back to Search</span>
          </button>
        </div>
      </div>

      {/* Hero Section */}
      <div className="relative h-96 overflow-hidden">
        <img
          src={monument.image}
          alt={monument.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent"></div>
        <div className="absolute bottom-0 left-0 right-0 p-8">
          <div className="max-w-7xl mx-auto">
            <div className="flex items-center space-x-3 mb-4">
              <span className={`px-4 py-2 rounded-full text-sm font-medium border ${getTypeColor(monument.type)}`}>
                {monument.type}
              </span>
              {monument.established && (
                <span className="px-4 py-2 rounded-full text-sm font-medium bg-white/20 text-white border border-white/30">
                  Est. {monument.established}
                </span>
              )}
            </div>
            <h1 className="text-4xl font-bold text-white mb-2">{monument.name}</h1>
            <div className="flex items-center space-x-2 text-white/90">
              <MapPin className="w-5 h-5" />
              <span className="text-lg">{monument.location}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - 2/3 width */}
          <div className="lg:col-span-2 space-y-8">
            {/* Overview */}
            <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Overview</h2>
              <p className="text-gray-700 leading-relaxed text-lg">{monument.overview}</p>
            </div>

            {/* History */}
            <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6">
              <div className="flex items-center space-x-2 mb-4">
                <Info className="w-6 h-6 text-blue-600" />
                <h2 className="text-2xl font-bold text-gray-900">History & Significance</h2>
              </div>
              <p className="text-gray-700 leading-relaxed">{monument.history}</p>
              {monument.significance && (
                <div className="mt-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <p className="text-blue-800 font-medium">{monument.significance}</p>
                </div>
              )}
            </div>

            {/* Architecture */}
            {monument.architecture && (
              <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6">
                <div className="flex items-center space-x-2 mb-4">
                  <Sparkles className="w-6 h-6 text-purple-600" />
                  <h2 className="text-2xl font-bold text-gray-900">Architecture</h2>
                </div>
                <p className="text-gray-700 leading-relaxed">{monument.architecture}</p>
              </div>
            )}

            {/* Left Column Info Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {monument.offerings && monument.offerings.length > 0 && (
                <InfoCard
                  title="Prasad & Offerings"
                  items={monument.offerings}
                  icon={<Gift className="w-5 h-5 text-orange-600" />}
                />
              )}

              {monument.amenities && monument.amenities.length > 0 && (
                <InfoCard
                  title="Amenities"
                  items={monument.amenities}
                  icon={<Star className="w-5 h-5 text-blue-600" />}
                />
              )}

              {monument.festivals && monument.festivals.length > 0 && (
                <InfoCard
                  title="Festivals"
                  items={monument.festivals}
                  icon={<Calendar className="w-5 h-5 text-purple-600" />}
                />
              )}

              {monument.deities && monument.deities.length > 0 && (
                <InfoCard
                  title="Deities"
                  items={monument.deities}
                  icon={<Heart className="w-5 h-5 text-red-600" />}
                />
              )}

              {monument.educationalServices && monument.educationalServices.length > 0 && (
                <InfoCard
                  title="Educational Services"
                  items={monument.educationalServices}
                  icon={<GraduationCap className="w-5 h-5 text-green-600" />}
                />
              )}

              {monument.foodForDevotees && monument.foodForDevotees.length > 0 && (
                <InfoCard
                  title="Food for Devotees"
                  items={monument.foodForDevotees}
                  icon={<Utensils className="w-5 h-5 text-orange-600" />}
                />
              )}
            </div>
          </div>

          {/* Right Column - 1/3 width */}
          <div className="space-y-6">
            {/* Quick Info */}
            <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Information</h3>
              <div className="space-y-4">
                {monument.timings && (
                  <div className="flex items-start space-x-3">
                    <Clock className="w-5 h-5 text-gray-500 mt-1" />
                    <div>
                      <p className="font-medium text-gray-900">Timings</p>
                      <p className="text-gray-600 text-sm">{monument.timings}</p>
                    </div>
                  </div>
                )}
                
                <div className="flex items-start space-x-3">
                  <MapPin className="w-5 h-5 text-gray-500 mt-1" />
                  <div>
                    <p className="font-medium text-gray-900">Location</p>
                    <p className="text-gray-600 text-sm">{monument.district}, {monument.state}</p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <Car className="w-5 h-5 text-gray-500 mt-1" />
                  <div>
                    <p className="font-medium text-gray-900">How to Reach</p>
                    <p className="text-gray-600 text-sm">{monument.accessibility}</p>
                  </div>
                </div>

                {monument.contact && (
                  <div className="flex items-start space-x-3">
                    <Phone className="w-5 h-5 text-gray-500 mt-1" />
                    <div>
                      <p className="font-medium text-gray-900">Contact</p>
                      <p className="text-gray-600 text-sm">{monument.contact}</p>
                    </div>
                  </div>
                )}

                {monument.website && (
                  <div className="flex items-start space-x-3">
                    <Globe className="w-5 h-5 text-gray-500 mt-1" />
                    <div>
                      <p className="font-medium text-gray-900">Website</p>
                      <a href={monument.website} className="text-orange-600 hover:text-orange-700 text-sm underline">
                        Official Website
                      </a>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Nearby Attractions */}
            {monument.nearbyAttractions && monument.nearbyAttractions.length > 0 && (
              <InfoCard
                title="Nearby Attractions"
                items={monument.nearbyAttractions}
                icon={<TreePine className="w-5 h-5 text-green-600" />}
              />
            )}

            {/* Nearby Hotels */}
            {monument.nearbyHotels && monument.nearbyHotels.length > 0 && (
              <InfoCard
                title="Nearby Hotels"
                items={monument.nearbyHotels}
                icon={<Hotel className="w-5 h-5 text-blue-600" />}
              />
            )}

            {/* Nearby Restaurants */}
            {monument.nearbyRestaurants && monument.nearbyRestaurants.length > 0 && (
              <InfoCard
                title="Nearby Restaurants"
                items={monument.nearbyRestaurants}
                icon={<Utensils className="w-5 h-5 text-red-600" />}
              />
            )}

            {/* Local Food */}
            {monument.localFood && monument.localFood.length > 0 && (
              <InfoCard
                title="Local Food Specialties"
                items={monument.localFood}
                icon={<Utensils className="w-5 h-5 text-orange-600" />}
              />
            )}

            {/* Action Buttons */}
            <div className="space-y-3">
              <button className="w-full flex items-center justify-center space-x-2 px-4 py-3 bg-gradient-to-r from-orange-500 to-red-600 text-white rounded-xl font-semibold hover:from-orange-600 hover:to-red-700 transition-all duration-200 shadow-lg hover:shadow-xl">
                <MapPin className="w-5 h-5" />
                <span>View on Map</span>
              </button>
              
              <button className="w-full flex items-center justify-center space-x-2 px-4 py-3 bg-white text-gray-700 border border-gray-300 rounded-xl font-semibold hover:bg-gray-50 transition-all duration-200">
                <Camera className="w-5 h-5" />
                <span>Add Photos</span>
              </button>
              
              <button className="w-full flex items-center justify-center space-x-2 px-4 py-3 bg-white text-gray-700 border border-gray-300 rounded-xl font-semibold hover:bg-gray-50 transition-all duration-200">
                <Users className="w-5 h-5" />
                <span>Suggest Edits</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MonumentDetail;